// prototypes
// void print_output(int, char**);
void flag_error(int);
void compile(char*);
void assign_flags(int, char**);
void success();